<template>
  <router-view/>
</template>

<style>

.form-error {
	width: 100%;
	margin-top: .25rem;
	font-size: .875em;
	color: #dc3545;
}

</style>
